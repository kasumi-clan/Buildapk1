"""Cấu hình và giới hạn tài nguyên. Mọi giá trị đọc từ biến môi trường GODLY_*."""
from __future__ import annotations

import os
from dataclasses import dataclass

MB = 1024 * 1024

# Chỉ các biến này được truyền cho Gradle. Mọi biến khác (GITHUB_TOKEN, secret,
# credentials storage, DATABASE_URL, ...) bị loại bỏ để source người dùng không đọc được.
DEFAULT_ENV_PASSTHROUGH = (
    "PATH", "HOME", "USER", "LANG", "LC_ALL", "TMPDIR",
    "JAVA_HOME", "ANDROID_HOME", "ANDROID_SDK_ROOT", "ANDROID_USER_HOME",
    "GRADLE_USER_HOME", "GRADLE_OPTS", "JAVA_TOOL_OPTIONS",
)


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ValueError(f"{name} phải là số nguyên, nhận được {raw!r}") from None
    if value <= 0:
        raise ValueError(f"{name} phải lớn hơn 0")
    return value


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    max_zip_bytes: int = 200 * MB
    max_extracted_bytes: int = 1024 * MB
    max_file_count: int = 20000
    max_file_bytes: int = 512 * MB
    max_compression_ratio: int = 200      # chỉ áp dụng cho entry > 1 MB
    extract_timeout_s: int = 300
    build_timeout_s: int = 1800
    kill_grace_s: int = 15
    max_project_depth: int = 6
    max_log_bytes: int = 20 * MB
    require_toolchain: bool = True        # kiểm tra JDK + Android SDK trước khi build
    allowed_gradle_hosts: tuple = ("services.gradle.org",)
    env_passthrough: tuple = DEFAULT_ENV_PASSTHROUGH

    @classmethod
    def from_env(cls) -> "Config":
        hosts = os.environ.get("GODLY_ALLOWED_GRADLE_HOSTS", "").strip()
        return cls(
            max_zip_bytes=_int("GODLY_MAX_ZIP_MB", 200) * MB,
            max_extracted_bytes=_int("GODLY_MAX_EXTRACTED_MB", 1024) * MB,
            max_file_count=_int("GODLY_MAX_FILES", 20000),
            max_file_bytes=_int("GODLY_MAX_FILE_MB", 512) * MB,
            max_compression_ratio=_int("GODLY_MAX_COMPRESSION_RATIO", 200),
            extract_timeout_s=_int("GODLY_EXTRACT_TIMEOUT_S", 300),
            build_timeout_s=_int("GODLY_BUILD_TIMEOUT_S", 1800),
            kill_grace_s=_int("GODLY_KILL_GRACE_S", 15),
            max_project_depth=_int("GODLY_MAX_PROJECT_DEPTH", 6),
            max_log_bytes=_int("GODLY_MAX_LOG_MB", 20) * MB,
            require_toolchain=_bool("GODLY_REQUIRE_TOOLCHAIN", True),
            allowed_gradle_hosts=tuple(h.strip().lower() for h in hosts.split(",") if h.strip())
            or ("services.gradle.org",),
        )
