"""Mã lỗi và exception dùng chung cho toàn bộ build engine."""
from __future__ import annotations

from enum import Enum


class ErrorCode(str, Enum):
    INVALID_ZIP = "INVALID_ZIP"
    ZIP_SECURITY_ERROR = "ZIP_SECURITY_ERROR"
    PROJECT_NOT_FOUND = "PROJECT_NOT_FOUND"
    GRADLE_WRAPPER_MISSING = "GRADLE_WRAPPER_MISSING"
    JDK_ERROR = "JDK_ERROR"
    ANDROID_SDK_ERROR = "ANDROID_SDK_ERROR"
    DEPENDENCY_DOWNLOAD_ERROR = "DEPENDENCY_DOWNLOAD_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    JAVA_COMPILATION_ERROR = "JAVA_COMPILATION_ERROR"
    KOTLIN_COMPILATION_ERROR = "KOTLIN_COMPILATION_ERROR"
    RESOURCE_ERROR = "RESOURCE_ERROR"
    MANIFEST_ERROR = "MANIFEST_ERROR"
    GRADLE_CONFIGURATION_ERROR = "GRADLE_CONFIGURATION_ERROR"
    APK_NOT_FOUND = "APK_NOT_FOUND"
    APK_VALIDATION_ERROR = "APK_VALIDATION_ERROR"
    BUILD_TIMEOUT = "BUILD_TIMEOUT"
    BUILD_CANCELLED = "BUILD_CANCELLED"
    STORAGE_ERROR = "STORAGE_ERROR"
    GITHUB_ERROR = "GITHUB_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    # Bổ sung ngoài danh sách gốc: Gradle fail nhưng log không khớp quy tắc nào.
    # Dùng mã riêng để không gán nhầm là lỗi nội bộ của engine.
    UNKNOWN_BUILD_ERROR = "UNKNOWN_BUILD_ERROR"


STRUCTURE_HINT = (
    "Cấu trúc ZIP đúng: giải nén ra phải thấy settings.gradle(.kts), build.gradle(.kts), "
    "gradlew, gradle/wrapper/gradle-wrapper.jar, gradle/wrapper/gradle-wrapper.properties "
    "và thư mục module (ví dụ app/). Cho phép có 1 thư mục bọc ngoài, ví dụ "
    "MyProject.zip → MyProject/settings.gradle.kts."
)


class EngineError(Exception):
    """Lỗi có mã rõ ràng; message/hint viết bằng tiếng Việt để hiển thị cho người dùng."""

    def __init__(self, code: ErrorCode, message: str, *, hint: str | None = None,
                 details: dict | None = None):
        super().__init__(message)
        self.code = ErrorCode(code)
        self.message = message
        self.hint = hint
        self.details = details or {}


class BuildCancelled(Exception):
    """Người dùng/hệ thống yêu cầu huỷ trước khi tiến trình build bắt đầu."""
