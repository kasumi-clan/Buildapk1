"""Dọn workspace, loại file build cũ do người dùng nén kèm, xoá workspace mồ côi."""
from __future__ import annotations

import os
import shutil
import sys
import time
from pathlib import Path

from errors import EngineError, ErrorCode


def _on_error(func, path, exc_info) -> None:
    try:
        os.chmod(path, 0o700)
        func(path)
    except OSError:
        pass


def safe_rmtree(path: Path | str, allowed_root: Path | str) -> None:
    """Chỉ xoá thư mục nằm TRONG allowed_root (không xoá chính allowed_root, không đi theo symlink)."""
    p = Path(path)
    if not os.path.lexists(p):
        return
    if p.is_symlink():
        p.unlink()
        return
    real, root = os.path.realpath(p), os.path.realpath(allowed_root)
    if real == root or not real.startswith(root + os.sep):
        raise EngineError(ErrorCode.INTERNAL_ERROR, "Từ chối xoá thư mục nằm ngoài vùng làm việc.")
    if sys.version_info >= (3, 12):
        shutil.rmtree(real, onexc=lambda f, pth, e: _on_error(f, pth, e))
    else:
        shutil.rmtree(real, onerror=_on_error)


def remove_stale_outputs(root: Path | str, logger=None) -> list:
    """Xoá thứ có thể làm kết quả build sai: APK cũ trong build/outputs, .gradle cũ, local.properties
    của máy người dùng (sdk.dir sai). Chỉ tác động lên bản giải nén trong workspace, không động tới ZIP gốc."""
    root = Path(root)
    removed: list = []
    targets: list = []
    for dirpath, dirnames, _ in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", "node_modules")]
        here = Path(dirpath)
        if here.name == "build" and (here / "outputs").is_dir():
            targets.append(here / "outputs")
            dirnames[:] = []
    for name in (".gradle",):
        if (root / name).is_dir():
            targets.append(root / name)
    for target in targets:
        safe_rmtree(target, root)
        removed.append(str(target.relative_to(root)))
    local = root / "local.properties"
    if local.is_file():
        local.unlink()
        removed.append("local.properties")
    if removed and logger:
        logger.info("Đã loại file build cũ khỏi workspace: " + ", ".join(removed))
    return removed


def cleanup_stale_workspaces(base: Path | str, max_age_s: int, prefix: str = "godly-build-") -> list:
    """Xoá các thư mục job mồ côi (engine bị kill giữa chừng) cũ hơn max_age_s."""
    base = Path(base)
    removed: list = []
    if not base.is_dir():
        return removed
    cutoff = time.time() - max_age_s
    for child in base.iterdir():
        if child.name.startswith(prefix) and child.is_dir() and not child.is_symlink() \
                and child.stat().st_mtime < cutoff:
            safe_rmtree(child, base)
            removed.append(child.name)
    return removed
