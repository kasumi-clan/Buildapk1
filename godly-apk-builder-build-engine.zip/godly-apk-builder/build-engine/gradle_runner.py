"""Chạy ./gradlew thật với môi trường tối thiểu, timeout, huỷ và dừng tiến trình có xác nhận."""
from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from config import Config
from errors import EngineError, ErrorCode
from logger import BuildLogger

_FLAVOR_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")
_MODULE_RE = re.compile(r"^:?[A-Za-z0-9_.\-]+(?::[A-Za-z0-9_.\-]+)*$")


@dataclass
class GradleResult:
    exit_code: int | None
    timed_out: bool
    cancelled: bool
    stopped_confirmed: bool
    duration_s: float
    task: str


def _cap(text: str) -> str:
    return text[:1].upper() + text[1:]


def build_task_name(module_path: str | None, build_type: str, flavor: str | None = None) -> str:
    """Ví dụ: (':app','debug',None) -> ':app:assembleDebug'. Input được kiểm tra chặt vì có thể đến từ người dùng."""
    if build_type not in ("debug", "release"):
        raise EngineError(ErrorCode.GRADLE_CONFIGURATION_ERROR, "Build type phải là debug hoặc release.")
    if flavor and not _FLAVOR_RE.match(flavor):
        raise EngineError(ErrorCode.GRADLE_CONFIGURATION_ERROR, "Tên product flavor không hợp lệ.")
    if module_path and module_path != ":" and not _MODULE_RE.match(module_path):
        raise EngineError(ErrorCode.GRADLE_CONFIGURATION_ERROR, "Tên module không hợp lệ.")
    task = f"assemble{_cap(flavor) if flavor else ''}{_cap(build_type)}"
    if module_path and module_path != ":":
        prefix = module_path if module_path.startswith(":") else ":" + module_path
        return f"{prefix}:{task}"
    return task


def check_toolchain(env=None) -> None:
    env = os.environ if env is None else env
    java_home = env.get("JAVA_HOME")
    if java_home:
        if not (Path(java_home) / "bin" / "java").is_file():
            raise EngineError(ErrorCode.JDK_ERROR, "JAVA_HOME trỏ tới thư mục không có bin/java.",
                              hint="Cài JDK 17 (hoặc bản dự án yêu cầu) và đặt JAVA_HOME đúng.")
    elif not shutil.which("java", path=env.get("PATH")):
        raise EngineError(ErrorCode.JDK_ERROR, "Không tìm thấy JDK (java) trong môi trường build.",
                          hint="Dùng actions/setup-java trong workflow hoặc cài JDK 17.")
    sdk = env.get("ANDROID_HOME") or env.get("ANDROID_SDK_ROOT")
    if not sdk or not Path(sdk).is_dir():
        raise EngineError(ErrorCode.ANDROID_SDK_ERROR, "Không tìm thấy Android SDK (ANDROID_HOME/ANDROID_SDK_ROOT).",
                          hint="Cài Android SDK và đặt ANDROID_HOME (workflow dùng android-actions/setup-android).")


def minimal_env(cfg: Config) -> dict:
    env = {k: os.environ[k] for k in cfg.env_passthrough if k in os.environ}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    env["CI"] = "true"
    return env


def _normalize_gradlew(script: Path, logger: BuildLogger) -> None:
    data = script.read_bytes()
    first_line = data.split(b"\n", 1)[0]
    if first_line.endswith(b"\r"):
        script.write_bytes(data.replace(b"\r\n", b"\n"))
        logger.warn("gradlew có kết thúc dòng kiểu Windows (CRLF); đã chuyển sang LF trong workspace.")
    os.chmod(script, 0o755)


def _stop_process_group(proc: subprocess.Popen, grace_s: int) -> bool:
    try:
        pgid = os.getpgid(proc.pid)
    except ProcessLookupError:
        return proc.poll() is not None
    for sig, wait in ((signal.SIGTERM, grace_s), (signal.SIGKILL, 10)):
        try:
            os.killpg(pgid, sig)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=wait)
            break
        except subprocess.TimeoutExpired:
            continue
    return proc.poll() is not None


def run_gradle(project_root: Path | str, task: str, cfg: Config, logger: BuildLogger, *,
               cancel_event: threading.Event | None = None, cancel_file: Path | str | None = None) -> GradleResult:
    root = Path(project_root)
    script = root / "gradlew"
    if not script.is_file():
        raise EngineError(ErrorCode.GRADLE_WRAPPER_MISSING, "Không có gradlew để chạy build.")
    _normalize_gradlew(script, logger)
    cmd = [str(script), "--no-daemon", "--console=plain", "--warning-mode=summary", task]
    logger.info("Chạy: " + " ".join(cmd[1:]))
    start = time.monotonic()
    try:
        proc = subprocess.Popen(
            cmd, cwd=root, env=minimal_env(cfg), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1, start_new_session=True)
    except OSError as exc:
        raise EngineError(ErrorCode.GRADLE_WRAPPER_MISSING, f"Không chạy được gradlew: {exc}",
                          hint="Kiểm tra gradlew có shebang hợp lệ (#!/bin/sh) và định dạng LF.") from None

    def pump() -> None:
        for line in proc.stdout:
            logger.log(line.rstrip("\n"))

    reader = threading.Thread(target=pump, daemon=True)
    reader.start()
    timed_out = cancelled = False
    deadline = start + cfg.build_timeout_s
    while True:
        try:
            proc.wait(timeout=0.2)
            break
        except subprocess.TimeoutExpired:
            pass
        if (cancel_event and cancel_event.is_set()) or (cancel_file and Path(cancel_file).exists()):
            cancelled = True
            logger.warn("Nhận yêu cầu huỷ; đang dừng tiến trình Gradle.")
        elif time.monotonic() > deadline:
            timed_out = True
            logger.error(f"Quá thời gian build ({cfg.build_timeout_s}s); đang dừng Gradle.")
        if cancelled or timed_out:
            break
    stopped = True
    if cancelled or timed_out:
        stopped = _stop_process_group(proc, cfg.kill_grace_s)
    reader.join(timeout=5)
    try:
        proc.stdout.close()
    except (OSError, ValueError):
        pass
    return GradleResult(exit_code=proc.poll(), timed_out=timed_out, cancelled=cancelled,
                        stopped_confirmed=stopped, duration_s=round(time.monotonic() - start, 2), task=task)
