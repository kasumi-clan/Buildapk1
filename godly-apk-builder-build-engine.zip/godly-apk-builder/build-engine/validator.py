"""Kiểm tra dự án Android đã được phát hiện có đủ điều kiện để build hay không."""
from __future__ import annotations

import zipfile
from pathlib import Path
from urllib.parse import urlparse

from config import Config
from errors import EngineError, ErrorCode, STRUCTURE_HINT
from project_detector import ModuleInfo, ProjectInfo


def read_wrapper_distribution_url(properties_file: Path) -> str | None:
    try:
        text = properties_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("distributionUrl"):
            _, _, value = line.partition("=")
            return value.strip().replace("\\:", ":")
    return None


def validate_project(info: ProjectInfo, cfg: Config) -> list:
    """Ném EngineError nếu không build được. Trả về danh sách cảnh báo."""
    warnings = list(info.warnings)
    if not info.application_modules:
        raise EngineError(
            ErrorCode.PROJECT_NOT_FOUND,
            "Tìm thấy dự án Gradle nhưng không có module Android application (plugin com.android.application).",
            hint=STRUCTURE_HINT)
    if not info.has_wrapper_script:
        raise EngineError(
            ErrorCode.GRADLE_WRAPPER_MISSING, "Thiếu file gradlew trong thư mục gốc dự án.",
            hint="Chạy 'gradle wrapper' trong dự án rồi nén lại, nhớ kèm gradlew và thư mục gradle/wrapper.")
    if not (info.has_wrapper_properties and info.has_wrapper_jar):
        raise EngineError(
            ErrorCode.GRADLE_WRAPPER_MISSING,
            "Thiếu gradle/wrapper/gradle-wrapper.jar hoặc gradle-wrapper.properties.",
            hint="Hãy nén kèm thư mục gradle/wrapper (đừng đưa nó vào .gitignore khi nén).")
    jar = info.root / "gradle" / "wrapper" / "gradle-wrapper.jar"
    if not zipfile.is_zipfile(jar):
        raise EngineError(ErrorCode.GRADLE_WRAPPER_MISSING, "gradle-wrapper.jar bị hỏng.",
                          hint="Tạo lại wrapper bằng 'gradle wrapper' rồi nén lại.")
    url = read_wrapper_distribution_url(info.root / "gradle" / "wrapper" / "gradle-wrapper.properties")
    if url:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        if parsed.scheme != "https" or host not in cfg.allowed_gradle_hosts:
            raise EngineError(
                ErrorCode.GRADLE_CONFIGURATION_ERROR,
                f"distributionUrl của Gradle wrapper trỏ tới nguồn không được phép ({host or url[:60]}).",
                hint="Chỉ cho phép tải Gradle từ https://services.gradle.org (có thể cấu hình GODLY_ALLOWED_GRADLE_HOSTS).")
    else:
        warnings.append("gradle-wrapper.properties không có distributionUrl.")
    for module in info.application_modules:
        manifest = module.directory / "src" / "main" / "AndroidManifest.xml"
        if not manifest.is_file():
            warnings.append(f"Module {module.gradle_path} không có src/main/AndroidManifest.xml "
                            "(có thể cấu hình sourceSets riêng).")
    if len(info.application_modules) > 1:
        names = ", ".join(m.gradle_path for m in info.application_modules)
        warnings.append(f"Có nhiều module application ({names}).")
    return warnings


def resolve_app_module(info: ProjectInfo, requested: str | None) -> ModuleInfo | None:
    """Trả về module cần build; None nghĩa là build mọi module application (task không có tiền tố)."""
    apps = info.application_modules
    if requested:
        wanted = requested if requested.startswith(":") else ":" + requested
        for module in apps:
            if module.gradle_path == wanted:
                return module
        raise EngineError(
            ErrorCode.PROJECT_NOT_FOUND,
            f"Module '{requested}' không tồn tại hoặc không phải module Android application.",
            hint="Các module application tìm thấy: " + ", ".join(m.gradle_path for m in apps))
    return apps[0] if len(apps) == 1 else None
