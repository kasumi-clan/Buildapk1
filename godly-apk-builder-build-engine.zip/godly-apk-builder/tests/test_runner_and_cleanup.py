import dataclasses
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

import helpers
from config import Config
from errors import EngineError, ErrorCode
from logger import BuildLogger
import cleanup
import gradle_runner as gr


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.root = self.tmp / "proj"
        self.root.mkdir()
        self.logger = BuildLogger(self.tmp / "b.log")
        self.cfg = dataclasses.replace(Config(), build_timeout_s=60, kill_grace_s=3)
        self.addCleanup(self.logger.close)

    def project(self, mode, gradlew=None):
        (self.root / ".fake-mode").write_text(mode)
        (self.root / ".fake.apk").write_bytes(helpers.make_apk_bytes())
        (self.root / "gradlew").write_bytes((gradlew or helpers.FAKE_GRADLEW).encode())

    def test_success_and_failure_exit_codes_and_logs_streamed(self):
        self.project("ok")
        r = gr.run_gradle(self.root, ":app:assembleDebug", self.cfg, self.logger)
        self.assertEqual((r.exit_code, r.timed_out, r.cancelled), (0, False, False))
        self.assertTrue(any("BUILD SUCCESSFUL" in l for l in self.logger.tail()))
        self.project("kotlin_error")
        self.assertEqual(gr.run_gradle(self.root, "x", self.cfg, self.logger).exit_code, 1)

    def test_timeout_kills_process_group_and_confirms(self):
        self.project("sleep")
        cfg = dataclasses.replace(self.cfg, build_timeout_s=1)
        t0 = time.time()
        r = gr.run_gradle(self.root, "x", cfg, self.logger)
        self.assertTrue(r.timed_out and r.stopped_confirmed)
        self.assertLess(time.time() - t0, 15)

    def test_cancel_by_event_and_by_file(self):
        self.project("sleep")
        ev = threading.Event()
        threading.Timer(1.0, ev.set).start()
        r = gr.run_gradle(self.root, "x", self.cfg, self.logger, cancel_event=ev)
        self.assertTrue(r.cancelled and r.stopped_confirmed and not r.timed_out)
        flag = self.tmp / "cancel.flag"
        threading.Timer(1.0, flag.touch).start()
        r = gr.run_gradle(self.root, "x", self.cfg, self.logger, cancel_file=flag)
        self.assertTrue(r.cancelled and r.stopped_confirmed)

    def test_secrets_are_not_passed_to_gradle(self):
        self.project("env")
        with mock.patch.dict(os.environ, {"SECRET_TOKEN": "super-secret-1", "DATABASE_URL": "postgres://u:p@h/db",
                                          "GITHUB_TOKEN": "ghs_" + "a" * 30}):
            gr.run_gradle(self.root, "x", self.cfg, self.logger)
        line = next(l for l in self.logger.tail() if l.startswith("leakcheck"))
        self.assertEqual(line, "leakcheck unset unset unset")

    def test_crlf_gradlew_is_normalized(self):
        self.project("ok", gradlew=helpers.FAKE_GRADLEW.replace("\n", "\r\n"))
        r = gr.run_gradle(self.root, "x", self.cfg, self.logger)
        self.assertEqual(r.exit_code, 0)
        self.assertNotIn(b"\r", (self.root / "gradlew").read_bytes())

    def test_missing_gradlew(self):
        with self.assertRaises(EngineError) as ctx:
            gr.run_gradle(self.root, "x", self.cfg, self.logger)
        self.assertEqual(ctx.exception.code, ErrorCode.GRADLE_WRAPPER_MISSING)

    def test_toolchain_checks(self):
        env = helpers.fake_toolchain_env(self.tmp)
        gr.check_toolchain(env)  # đủ -> không lỗi
        with self.assertRaises(EngineError) as c:
            gr.check_toolchain({"JAVA_HOME": str(self.tmp / "nope"), **{k: v for k, v in env.items() if k != "JAVA_HOME"}})
        self.assertEqual(c.exception.code, ErrorCode.JDK_ERROR)
        with self.assertRaises(EngineError) as c:
            gr.check_toolchain({"JAVA_HOME": env["JAVA_HOME"]})
        self.assertEqual(c.exception.code, ErrorCode.ANDROID_SDK_ERROR)
        with self.assertRaises(EngineError) as c:
            gr.check_toolchain({"PATH": str(self.tmp)})
        self.assertEqual(c.exception.code, ErrorCode.JDK_ERROR)


class CleanupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def test_safe_rmtree_refuses_outside_and_root(self):
        base = self.tmp / "base"; (base / "job").mkdir(parents=True)
        outside = self.tmp / "outside"; outside.mkdir(); (outside / "keep.txt").write_text("x")
        with self.assertRaises(EngineError):
            cleanup.safe_rmtree(outside, base)
        with self.assertRaises(EngineError):
            cleanup.safe_rmtree(base, base)
        (base / "job" / "ro").mkdir(); (base / "job" / "ro" / "f").write_text("x"); os.chmod(base / "job" / "ro", 0o500)
        cleanup.safe_rmtree(base / "job", base)
        self.assertFalse((base / "job").exists())
        self.assertTrue((outside / "keep.txt").exists())

    def test_symlink_is_unlinked_not_followed(self):
        base = self.tmp / "base"; base.mkdir()
        target = self.tmp / "target"; target.mkdir(); (target / "f").write_text("x")
        (base / "link").symlink_to(target)
        cleanup.safe_rmtree(base / "link", base)
        self.assertFalse(os.path.lexists(base / "link"))
        self.assertTrue((target / "f").exists())

    def test_remove_stale_outputs(self):
        root = self.tmp / "p"
        for rel in ("app/build/outputs/apk/debug/old.apk", ".gradle/8.7/x", "local.properties", "app/src/Main.kt"):
            f = root / rel; f.parent.mkdir(parents=True, exist_ok=True); f.write_text("x")
        removed = cleanup.remove_stale_outputs(root)
        self.assertEqual(sorted(removed), [".gradle", "app/build/outputs", "local.properties"])
        self.assertTrue((root / "app/src/Main.kt").exists())
        self.assertFalse((root / "app/build/outputs").exists())

    def test_cleanup_stale_workspaces(self):
        base = self.tmp / "ws"; base.mkdir()
        old, new, other = base / "godly-build-old", base / "godly-build-new", base / "keepme"
        for d in (old, new, other):
            d.mkdir()
        os.utime(old, (1, 1)); os.utime(other, (1, 1))
        self.assertEqual(cleanup.cleanup_stale_workspaces(base, 3600), ["godly-build-old"])
        self.assertTrue(new.exists() and other.exists())


if __name__ == "__main__":
    unittest.main()
