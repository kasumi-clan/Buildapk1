import dataclasses
import tempfile
import unittest
from pathlib import Path

import helpers
from config import Config
from errors import EngineError, ErrorCode
import extractor
import gradle_runner
import project_detector as pd
import validator


def write_tree(root: Path, files: dict):
    for rel, content in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content if isinstance(content, bytes) else str(content).encode())


class ProjectTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.cfg = Config()

    def detect(self, files, wrapper_dir=None):
        base = self.tmp / "ex"
        import shutil
        shutil.rmtree(base, ignore_errors=True)
        zp = helpers.make_zip(self.tmp / "p.zip", files, wrapper_dir=wrapper_dir)
        extractor.safe_extract(zp, base, self.cfg)
        return base, pd.detect_project(base)

    def test_kotlin_dsl_root_at_top(self):
        base, info = self.detect(helpers.android_project_files("kts"))
        self.assertEqual(info.root, base)
        self.assertEqual(info.dsl, "kotlin")
        self.assertEqual([m.gradle_path for m in info.application_modules], [":app"])
        self.assertEqual(validator.validate_project(info, self.cfg), [])

    def test_groovy_dsl_with_wrapper_folder(self):
        base, info = self.detect(helpers.android_project_files("groovy"), wrapper_dir="MyAndroidProject")
        self.assertEqual(info.root, base / "MyAndroidProject")
        self.assertEqual(info.dsl, "groovy")
        self.assertEqual(len(info.application_modules), 1)

    def test_custom_module_name_not_assumed_app(self):
        _, info = self.detect(helpers.android_project_files("kts", module="mobile"))
        self.assertEqual([m.gradle_path for m in info.application_modules], [":mobile"])
        self.assertEqual(validator.resolve_app_module(info, None).gradle_path, ":mobile")

    def test_multi_module_and_version_catalog_alias(self):
        files = helpers.android_project_files("kts")
        files["settings.gradle.kts"] = 'rootProject.name = "X"\ninclude(\n  ":app",\n  ":core:data",\n  ":wear"\n)\n// include(":ignored")\n'
        files["core/data/build.gradle.kts"] = 'plugins { id("com.android.library") }'
        files["wear/build.gradle.kts"] = "plugins { alias(libs.plugins.android.application) }"
        files["build.gradle.kts"] = 'plugins { id("com.android.application") version "8.5.0" apply false }'
        _, info = self.detect(files)
        paths = {m.gradle_path: m for m in info.modules}
        self.assertNotIn(":ignored", paths)
        self.assertTrue(paths[":core:data"].is_library and not paths[":core:data"].is_application)
        self.assertEqual(sorted(m.gradle_path for m in info.application_modules), [":app", ":wear"])
        self.assertFalse(paths[":"].is_application)  # "apply false" ở root không tính
        self.assertIsNone(validator.resolve_app_module(info, None))  # nhiều app -> build tất cả
        self.assertEqual(validator.resolve_app_module(info, "wear").gradle_path, ":wear")
        with self.assertRaises(EngineError):
            validator.resolve_app_module(info, ":core:data")

    def test_product_flavors_detected_kotlin_and_groovy(self):
        files = helpers.android_project_files("kts")
        files["app/build.gradle.kts"] = (
            'plugins { id("com.android.application") }\nandroid {\n  flavorDimensions += "tier"\n'
            '  productFlavors {\n    create("free") { dimension = "tier" }\n    create("paid") { dimension = "tier" }\n  }\n}\n')
        _, info = self.detect(files)
        self.assertEqual(info.application_modules[0].flavors, ["free", "paid"])
        self.assertEqual(pd._extract_flavors("android { productFlavors { demo { applicationIdSuffix '.d' }\n full { } } }"),
                         ["demo", "full"])

    def test_nested_build_logic_does_not_hide_real_root(self):
        files = helpers.android_project_files("kts")
        files["build-logic/settings.gradle.kts"] = "// included build"
        _, info = self.detect(files, wrapper_dir="Proj")
        self.assertTrue(str(info.root).endswith("/ex/Proj"))

    def test_stale_build_dir_not_scanned_for_roots(self):
        files = helpers.android_project_files("kts")
        files["app/build/tmp/settings.gradle"] = "junk"
        _, info = self.detect(files)
        self.assertEqual(info.root.name, "ex")

    def test_no_gradle_project_fails_with_structure_hint(self):
        with self.assertRaises(EngineError) as ctx:
            self.detect({"README.md": "hello", "src/a.kt": "x"})
        self.assertEqual(ctx.exception.code, ErrorCode.PROJECT_NOT_FOUND)
        self.assertIn("settings.gradle", ctx.exception.hint)

    def test_library_only_project_rejected(self):
        _, info = self.detect(helpers.android_project_files("kts", app_plugin=False))
        with self.assertRaises(EngineError) as ctx:
            validator.validate_project(info, self.cfg)
        self.assertEqual(ctx.exception.code, ErrorCode.PROJECT_NOT_FOUND)

    def test_missing_gradlew_and_missing_jar(self):
        _, info = self.detect(helpers.android_project_files("kts", wrapper=False))
        with self.assertRaises(EngineError) as ctx:
            validator.validate_project(info, self.cfg)
        self.assertEqual(ctx.exception.code, ErrorCode.GRADLE_WRAPPER_MISSING)
        files = helpers.android_project_files("kts")
        del files["gradle/wrapper/gradle-wrapper.jar"]
        _, info = self.detect(files)
        with self.assertRaises(EngineError) as ctx:
            validator.validate_project(info, self.cfg)
        self.assertEqual(ctx.exception.code, ErrorCode.GRADLE_WRAPPER_MISSING)

    def test_corrupt_wrapper_jar(self):
        files = helpers.android_project_files("kts")
        files["gradle/wrapper/gradle-wrapper.jar"] = b"not a jar"
        _, info = self.detect(files)
        with self.assertRaises(EngineError) as ctx:
            validator.validate_project(info, self.cfg)
        self.assertEqual(ctx.exception.code, ErrorCode.GRADLE_WRAPPER_MISSING)

    def test_malicious_distribution_url_rejected(self):
        for url in ("https\\://evil.example.com/gradle.zip", "http\\://services.gradle.org/x.zip"):
            with self.subTest(url=url):
                files = helpers.android_project_files("kts")
                files["gradle/wrapper/gradle-wrapper.properties"] = f"distributionUrl={url}\n"
                base = self.tmp / "ex"
                import shutil; shutil.rmtree(base, ignore_errors=True)
                _, info = self.detect(files)
                with self.assertRaises(EngineError) as ctx:
                    validator.validate_project(info, self.cfg)
                self.assertEqual(ctx.exception.code, ErrorCode.GRADLE_CONFIGURATION_ERROR)
        cfg = dataclasses.replace(self.cfg, allowed_gradle_hosts=("mirror.corp.example",))
        files = helpers.android_project_files("kts")
        files["gradle/wrapper/gradle-wrapper.properties"] = "distributionUrl=https\\://mirror.corp.example/g.zip\n"
        import shutil; shutil.rmtree(self.tmp / "ex", ignore_errors=True)
        _, info = self.detect(files)
        validator.validate_project(info, cfg)  # host cấu hình được phép

    def test_task_name_builder_and_injection_guard(self):
        b = gradle_runner.build_task_name
        self.assertEqual(b(":app", "debug"), ":app:assembleDebug")
        self.assertEqual(b(":feature:app", "release", "freeRed"), ":feature:app:assembleFreeRedRelease")
        self.assertEqual(b(None, "debug"), "assembleDebug")
        self.assertEqual(b(":", "debug"), "assembleDebug")
        for bad_flavor in ("x; rm -rf /", "--init-script", "a b"):
            with self.assertRaises(EngineError):
                b(":app", "debug", bad_flavor)
        with self.assertRaises(EngineError):
            b(":app;id", "debug")
        with self.assertRaises(EngineError):
            b(":app", "staging")


if __name__ == "__main__":
    unittest.main()
