"""Tiện ích tạo ZIP / dự án Android giả / APK giả (cấu trúc thật, nhưng không phải app thật)."""
import io
import os
import struct
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "build-engine"))

FAKE_GRADLEW = r"""#!/bin/sh
here="$(cd "$(dirname "$0")" && pwd)"
mode="$(cat "$here/.fake-mode" 2>/dev/null || echo ok)"
echo "> Task :app:preBuild UP-TO-DATE"
case "$mode" in
  ok)
    mkdir -p "$here/app/build/outputs/apk/debug"
    cp "$here/.fake.apk" "$here/app/build/outputs/apk/debug/app-debug.apk"
    echo "BUILD SUCCESSFUL in 3s"; exit 0;;
  multi)
    mkdir -p "$here/app/build/outputs/apk/debug"
    cp "$here/.fake.apk" "$here/app/build/outputs/apk/debug/app-arm64-v8a-debug.apk"
    cp "$here/.fake.apk" "$here/app/build/outputs/apk/debug/app-universal-debug.apk"
    echo "BUILD SUCCESSFUL in 3s"; exit 0;;
  no_apk)
    echo "BUILD SUCCESSFUL in 1s"; exit 0;;
  kotlin_error)
    echo "e: file://$here/app/src/main/java/com/x/MainActivity.kt:12:34 Unresolved reference: foo"
    echo "> Task :app:compileDebugKotlin FAILED"
    echo "FAILURE: Build failed with an exception."
    echo "* What went wrong:"
    echo "Execution failed for task ':app:compileDebugKotlin'."
    echo "> Compilation error. See log for more details"
    echo "* Try:"
    exit 1;;
  network)
    echo "Could not GET 'https://dl.google.com/x.pom'. Received status code 500"
    echo "java.net.UnknownHostException: dl.google.com"
    exit 1;;
  secret)
    echo "using token=ghp_abcdefghijklmnopqrstuvwxyz0123456789ABCD for upload"
    echo "something odd happened"; exit 1;;
  unknown)
    echo "* What went wrong:"; echo "Something strange"; echo "* Try:"; exit 1;;
  env)
    echo "leakcheck ${SECRET_TOKEN:-unset} ${DATABASE_URL:-unset} ${GITHUB_TOKEN:-unset}"; exit 1;;
  sleep)
    echo started; sleep 30; exit 0;;
esac
"""


def _str(s):
    return struct.pack("<H", len(s)) + s.encode("utf-16-le") + b"\x00\x00"


def build_axml(package="com.example.app", version_code=7, version_name="1.2.3", debuggable=False):
    strings = ["versionCode", "versionName", "package", "debuggable", "manifest", "application", package, version_name]
    data, offsets = b"", []
    for s in strings:
        offsets.append(len(data))
        data += _str(s)
    while len(data) % 4:
        data += b"\x00"
    strings_start = 28 + 4 * len(strings)
    pool = struct.pack("<HHIIIIII", 1, 28, strings_start + len(data), len(strings), 0, 0, strings_start, 0)
    pool += b"".join(struct.pack("<I", o) for o in offsets) + data

    def attr(name, raw, dtype, value):
        return struct.pack("<IIIHBBI", 0xFFFFFFFF, name, raw, 8, 0, dtype, value)

    def element(name, attrs):
        body = struct.pack("<IIHHHHHH", 0xFFFFFFFF, name, 20, 20, len(attrs), 0, 0, 0) + b"".join(attrs)
        return struct.pack("<HHIII", 0x0102, 16, 16 + len(body), 1, 0xFFFFFFFF) + body

    manifest = element(4, [attr(2, 6, 3, 6), attr(0, 0xFFFFFFFF, 0x10, version_code), attr(1, 7, 3, 7)])
    app = element(5, [attr(3, 0xFFFFFFFF, 0x12, 0xFFFFFFFF if debuggable else 0)])
    body = pool + manifest + app
    return struct.pack("<HHI", 3, 8, 8 + len(body)) + body


def make_apk_bytes(signed=True, manifest=True, **kw):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        if manifest:
            z.writestr("AndroidManifest.xml", build_axml(**kw))
        z.writestr("classes.dex", b"dex\n035\x00" + b"\x01" * 64)
        if signed:
            z.writestr("META-INF/CERT.SF", b"Signature-Version: 1.0\n")
            z.writestr("META-INF/CERT.RSA", b"\x30\x82fake")
    return buf.getvalue()


def make_zip(path, files, wrapper_dir=None):
    """files: {relative_path: bytes|str|(bytes, mode)}; wrapper_dir đặt tất cả vào 1 thư mục bọc ngoài."""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in files.items():
            mode = 0o644
            if isinstance(content, tuple):
                content, mode = content
            if isinstance(content, str):
                content = content.encode()
            info = zipfile.ZipInfo((wrapper_dir + "/" if wrapper_dir else "") + name)
            info.create_system = 3
            info.external_attr = (0o100000 | mode) << 16
            z.writestr(info, content)
    return str(path)


def android_project_files(dsl="kts", mode="ok", apk=None, module="app", app_plugin=True, wrapper=True):
    ext = ".kts" if dsl == "kts" else ""
    inc = f'include(":{module}")' if dsl == "kts" else f"include ':{module}'"
    plugin = 'plugins { id("com.android.application") }' if dsl == "kts" else "apply plugin: 'com.android.application'"
    files = {
        f"settings.gradle{ext}": f"rootProject.name = \"Demo\"\n{inc}\n",
        f"build.gradle{ext}": "// root\n",
        f"{module}/build.gradle{ext}": (plugin if app_plugin else "plugins { id(\"com.android.library\") }") + "\nandroid { }\n",
        f"{module}/src/main/AndroidManifest.xml": "<manifest/>",
        ".fake-mode": mode,
        ".fake.apk": apk if apk is not None else make_apk_bytes(),
    }
    if wrapper:
        files["gradlew"] = (FAKE_GRADLEW, 0o755)
        files["gradle/wrapper/gradle-wrapper.properties"] = (
            "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip\n")
        jar = io.BytesIO()
        with zipfile.ZipFile(jar, "w") as z:
            z.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\n")
        files["gradle/wrapper/gradle-wrapper.jar"] = jar.getvalue()
    return files


def fake_toolchain_env(tmp):
    """Tạo JAVA_HOME/ANDROID_HOME giả để qua bước kiểm tra toolchain (không phải JDK/SDK thật)."""
    java = Path(tmp) / "jdk" / "bin"
    java.mkdir(parents=True, exist_ok=True)
    (java / "java").write_text("#!/bin/sh\n")
    sdk = Path(tmp) / "sdk"
    sdk.mkdir(exist_ok=True)
    return {"JAVA_HOME": str(Path(tmp) / "jdk"), "ANDROID_HOME": str(sdk)}
